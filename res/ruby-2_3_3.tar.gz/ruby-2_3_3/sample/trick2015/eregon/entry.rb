class String;def[]*a;$*<<a;b;end;end;
_=0;z="C=Fiber;s=$*;a=*0..8;l=C.new{e
xit},*a.product(a).select{|r,c|s[r][c
]==0}."[1,9,_, _,_,8, _,_,5]+"map{|r,
c|C.ne"[_,_,2, _,5,_, _,8,9]+"w{o=s[r
][c];l"[8,_,6, 7,4,_, _,_,_]+"oop{(1.
.9).map{|n|C.yield(s[r][c]=n)if a.non
e?{|k|"[_,_,_, _,_,4, _,9,2]+"s[r][k]
==n||s"[_,2,3, _,7,_, 8,1,_]+"[k][c]=
=n||s["[5,6,_, 8,_,_, _,_,_]+"r-r%3+k
%3][c-c%3+k/3]==n}};s[r][c]=o;C.yield
}}},C."[_,_,_, _,2,7, 9,_,3]+"new{loo
p{puts"[9,3,_, _,8,_, 1,_,_]+" s.map{
|r|r*'"[2,_,_, 5,_,_, _,4,8]+" '}<<''
;C.yield}};c=l[i=1];loop{c=l[i+=c.res
ume ? 1:-1]}";eval z.tr ?\n,''
