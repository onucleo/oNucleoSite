def _(&b)$><<->(x){x ? (String===x ?x.upcase:
(Class===x ? x : x.class).name[$a?0:($a=5)]):
" "}[ begin b[];rescue Exception;$!;end ] end

_ {                 return                  }
_ {            method(:p).unbind            }
_ {                eval "{ "                }
_ {           Thread.current.join           }
_ {                   nil                   }
_ {                 select                  }
_ {                  ruby                   }
_ {               self.class                }
_ {          Thread.current.group           }
_ {                nil.to_h                 }
_ {          "\xFF".encode("big5")          }
_ {                  raise                  }
_ {                 [0][1]                  }
_ {           Regexp.compile "*"            }
_ {           RUBY_COPYRIGHT[32]            }
_ {                 binding                 }
_ {            :s.class.name[1]             }
_ {                  warn                   }
_ {                [a: :b][0]               }
_ {                 methods                 }
_ {                IO.class                 }
_ {               {}.fetch(0)               }
_ {                open " "                 }
_ {               1000000.chr               }
